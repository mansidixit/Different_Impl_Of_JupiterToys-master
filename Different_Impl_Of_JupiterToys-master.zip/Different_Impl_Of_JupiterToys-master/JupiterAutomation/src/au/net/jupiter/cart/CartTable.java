package au.net.jupiter.cart;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import au.net.jupiter.ui.Table;

public class CartTable {

	private Table table;
	
	public CartTable(WebElement element) {
		this.table = new Table(element);
	}

	public double getPrice(String itemName) throws Exception {
		return Double.parseDouble(this.table.getCellElement("Item", itemName, "Price").getText().replace("$",""));
	}
	
	public String getItem(String itemName) throws Exception{
		return this.table.getCellElement("Item",itemName,"Item").getText();
	}
	public double getSubTotal(String itemName) throws Exception{
		return Double.parseDouble(this.table.getCellElement("Item",itemName,"Subtotal").getText().replace("$",""));
	}
	public void clickDeleteButton(String itemName) throws Exception{
		this.table.getCellElement("Item",itemName,"Actions").findElement(By.className("remove-item")).click();
	}

	public double getTotal() {
		return Double.parseDouble(this.table.getFooterRows().get(0).getText().replaceFirst("(.)*: ", ""));
	}
	
	public long getQuantity(String itemName) throws Exception{
		return Long.parseLong(getQuantityElement(itemName).getAttribute("value"));
	}
	public void setQuantity(String itemName, String quantity) throws Exception {
		getQuantityElement(itemName).clear();
		getQuantityElement(itemName).sendKeys(quantity);
	}
	private WebElement getQuantityElement(String itemName) throws Exception{
		return this.table.getCellElement("Item",itemName,"Quantity").findElement(By.tagName("input"));
	}
	
}
