package au.net.jupiter.ui;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class Table {

	private WebElement table;
	
	public Table(WebElement table) {
		this.table = table;
	}
	
	private List<WebElement> getAllDataRows(){
		return this.table.findElements(By.cssSelector("tbody tr"));
	}
	
	public WebElement getCellElement(String findColumn, String findValue, String returnColumn) throws Exception{
		int findColumnIndex = this.getColumnIndex(findColumn);
		int returnColumnIndex = this.getColumnIndex(returnColumn);
		
		List<WebElement> rows = this.getAllDataRows();
		for(WebElement row : rows) {
			List<WebElement> cells = row.findElements(By.tagName("td"));
			if(cells.get(findColumnIndex).getText().equals(findValue)) {
				return cells.get(returnColumnIndex);
			}
		}
		throw new Exception("No Matching cell found");
	}
	
	public int getColumnIndex(String columnName) throws Exception {
		List<WebElement> columnHearderList = this.table.findElements(By.tagName("th"));
		for(int i=0;i<columnHearderList.size();i++){
			if(columnHearderList.get(i).getText().equals(columnName)){
				return i;
			}
		}
		throw new Exception("Column not found : " +columnName);
	}
	
	public List<WebElement> getFooterRows(){
		return this.table.findElements(By.cssSelector("tfoot tr"));
	}
	
	
	
	
}
