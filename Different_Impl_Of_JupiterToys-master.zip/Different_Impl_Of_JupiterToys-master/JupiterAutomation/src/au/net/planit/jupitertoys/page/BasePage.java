package au.net.planit.jupitertoys.page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class BasePage {
	
	protected WebDriver driver;
	
	public BasePage(WebDriver driver) {
		this.driver = driver;
	}

	public void clickShopMenu() {
		this.driver.findElement(By.cssSelector("#nav-shop > a")).click();
	}

	public void clickCartMenu() {
		this.driver.findElement(By.cssSelector("#nav-cart > a")).click();
	}

	public void clickContactMenu() {
		this.driver.findElement(By.cssSelector("#nav-contact > a")).click();
	}
	
	public String getProductCountInCartMenu(){
		return this.driver.findElement(By.className("cart-count")).getText();
	}
	
	public void confirmDeletion() {
		this.driver.findElement(By.cssSelector(".modal-footer > a")).click();
	}
}