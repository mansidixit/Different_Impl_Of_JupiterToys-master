package au.net.planit.jupitertoys.page;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ContactPage extends BasePage {

	public ContactPage(WebDriver driver) {
		super(driver);
	}

	public void clickSubmit() {
		this.driver.findElement(By.linkText("Submit")).click();
	}

	//foreName
	private WebElement getForeNameElement(){
		return this.driver.findElement(By.id("forename"));
	}
	
	public String getForeNameValidationError() {
		return getValidationError(By.id("forename-err"));
	}
	
	public void setForeName(String foreName) {
		getForeNameElement().sendKeys(foreName);
	}
	
	public String getForeName() {
		return getForeNameElement().getAttribute("value");
	}
	
	
	
	//email
	private WebElement getEmailElement(){
		return this.driver.findElement(By.id("email"));
	}
	public String getEmailValidationError() {
		return getValidationError(By.id("email-err"));
	}
	public void setEmail(String email) {
		getEmailElement().sendKeys(email);
	}
	public String getEmail() {
		return getEmailElement().getAttribute("value");
	}
	
	
	//Telephone
	private WebElement getTelephoneElement(){
		return this.driver.findElement(By.id("telephone"));
	}
	public void setTelephone(String telephone) {
		getTelephoneElement().sendKeys(telephone);
	}
	public String getTelephone() {
		return getTelephoneElement().getAttribute("value");
	}
	
	//message
	public String getMessageValidationError() {
		return getValidationError(By.id("message-err"));
	}
	private WebElement getMessageElement(){
		return this.driver.findElement(By.id("message"));
	}
	public void setMessage(String message) {
		getMessageElement().sendKeys(message);
	}
	public String getMessage() {
		return getMessageElement().getAttribute("value");
	}
	

	
//surname
	private WebElement getSurnameElement(){
		return this.driver.findElement(By.id("surname"));
	}
	public void setSurname(String surname) {
		getSurnameElement().sendKeys(surname);
	}
	
	public String getSurname() {
		return getSurnameElement().getAttribute("value");
	}
	

	public String getSuccessMssage() {
		
		WebElement successMsgElement = (new WebDriverWait(driver, 60))
				  .until(ExpectedConditions.presenceOfElementLocated(By.className("alert-success")));
		
		return successMsgElement.getText();
	}
	
	private String getValidationError(By findBy) {
		List<WebElement> validationErrorList = this.driver.findElements(findBy);
		if(validationErrorList.size()>0)
			return validationErrorList.get(0).getText();
		return "";
	}
	

}
