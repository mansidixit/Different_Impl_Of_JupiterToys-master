package au.net.planit.jupitertoys.test;



import org.junit.Assert;
import org.junit.Test;

import au.net.planit.jupiter.products.CompareByPrice;
import au.net.planit.jupiter.products.CompareByTitle;
import au.net.planit.jupiter.products.Product;
import au.net.planit.jupitertoys.page.HomePage;
import au.net.planit.jupitertoys.page.ShopPage;

public class ShopPageTests  extends BaseTest {

	@Test
	public void testProductPriceInShop() throws Exception {
		
		//click Shop menu from Home page
		HomePage homePage = new HomePage(driver);
		homePage.clickShopMenu();
		
		//select a product for test
		ShopPage shopPage = new ShopPage(driver);
		double myPrice = 9.99;
		String myProductTitle="Smiley Face";
		
		Product product = shopPage.getProduct(new CompareByTitle(myProductTitle));
		
		//Check the productPrice
		Assert.assertEquals(myPrice, product.getProductPrice(),0);

	}
	
	@Test
	public void testCartCountIncrementsWhenProductAddedToCart() throws Exception {
		
		//click Contact menu from Home page
		HomePage homePage = new HomePage(driver);
		homePage.clickShopMenu();
		
		ShopPage shopPage = new ShopPage(driver);
		
		shopPage.getProduct(new CompareByTitle("Funny Cow")).clickBuyButton();
		shopPage.getProduct(new CompareByPrice(12.99)).clickBuyButton();
		Assert.assertEquals("Tha number of items bought do not match the number shown Cart", "2",shopPage.getProductCountInCartMenu());
	}
	
}
