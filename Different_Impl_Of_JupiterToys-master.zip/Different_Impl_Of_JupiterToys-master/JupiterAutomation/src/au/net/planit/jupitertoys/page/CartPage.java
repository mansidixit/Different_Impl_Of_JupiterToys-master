package au.net.planit.jupitertoys.page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import au.net.jupiter.cart.CartTable;

public class CartPage extends BasePage{

	public CartPage(WebDriver driver) {
		super(driver);
	}

	private CartTable getCartTable(){
		return (new CartTable(driver.findElement(By.className("cart-items"))));
	}
	
	public double getSubtotal(String productTitle) throws Exception{
		return getCartTable().getSubTotal(productTitle);
	}

	public double getPrice(String productTitle)throws Exception {
		return getCartTable().getPrice(productTitle);
	}

	public long getQuantity(String productTitle)throws Exception {
		return getCartTable().getQuantity(productTitle);
	}

	public void clickDeleteButton(String productTitle) throws Exception {
		getCartTable().clickDeleteButton(productTitle);
	}
	
	public String getEmptyCartMessage(){
		return this.driver.findElement(By.cssSelector(".alert")).getText().replaceFirst(".\n", "");
	}
	
	public double getTotal(){
		return getCartTable().getTotal();
	}

	public void setQuantity(String productTitle,String quantity) throws Exception {
		getCartTable().setQuantity(productTitle,quantity);
		
	}
}
