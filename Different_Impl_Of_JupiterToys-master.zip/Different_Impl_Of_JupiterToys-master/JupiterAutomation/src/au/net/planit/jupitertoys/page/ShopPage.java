package au.net.planit.jupitertoys.page;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import au.net.planit.jupiter.products.IComparison;
import au.net.planit.jupiter.products.Product;

public class ShopPage extends BasePage {

	public ShopPage(WebDriver driver) {
		super(driver);
	}

	public Product getProduct(IComparison compareProductBy) throws Exception {
		
		List<WebElement> elements = this.driver.findElements(By.className("product"));
		for(WebElement el : elements){
			Product p = new Product(el);
			if(compareProductBy.compareProduct(p))
				return p;
		}
		
		throw new Exception("Product not found " + compareProductBy.toString()); 
	}
}
