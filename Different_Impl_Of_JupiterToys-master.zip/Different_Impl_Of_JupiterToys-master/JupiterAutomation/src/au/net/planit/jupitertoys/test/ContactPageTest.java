package au.net.planit.jupitertoys.test;



import org.junit.Assert;
import org.junit.Test;

import au.net.planit.jupitertoys.page.ContactPage;
import au.net.planit.jupitertoys.page.HomePage;

public class ContactPageTest extends BaseTest{

	@Test
	public void testMandatoryFields() {
		
		//click Contact menu from Home page
		HomePage homePage = new HomePage(driver);
		homePage.clickContactMenu();
		
		//Click submit from Contact page
		ContactPage contactPage = new ContactPage(driver);
		contactPage.clickSubmit();
				
		//check the error message
				Assert.assertEquals("Checks the foreName validation error message","Forename is required",contactPage.getForeNameValidationError());
				Assert.assertEquals("Checks the Email validation error message","Email is required",contactPage.getEmailValidationError());
				Assert.assertEquals("Checks the Message validation error message","Message is required",contactPage.getMessageValidationError());
	
	}
	
	@Test
	public void testContactUsFormSubmission() {
		
		HomePage homePage = new HomePage(driver);
		homePage.clickContactMenu();
		
		String foreName="Mansi";
		ContactPage contactPage = new ContactPage(driver);
		contactPage.setForeName(foreName);
		contactPage.setSurname("Dixit");
		contactPage.setEmail("abc@abc.com");
		contactPage.setTelephone("123456");
		contactPage.setMessage("This is a demo Test");
		
		contactPage.clickSubmit();
				
		Assert.assertTrue("Check the correct forName is printed on the success page",contactPage.getSuccessMssage().contains(foreName));
	
	}

}
