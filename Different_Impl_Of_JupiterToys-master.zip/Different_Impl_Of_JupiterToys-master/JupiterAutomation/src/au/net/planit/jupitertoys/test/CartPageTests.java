package au.net.planit.jupitertoys.test;

import org.junit.Assert;
import org.junit.Test;

import au.net.planit.jupiter.products.CompareByTitle;
import au.net.planit.jupiter.products.Product;
import au.net.planit.jupitertoys.page.CartPage;
import au.net.planit.jupitertoys.page.HomePage;
import au.net.planit.jupitertoys.page.ShopPage;

public class CartPageTests extends BaseTest {

	@Test
	public void testProductPriceAndQuantityInCart() throws Exception {

		String productTitle1 = "Teddy Bear";
		String productTitle2 = "Handmade Doll";
		double myPrice1 = 12.99;
		long myQuantity2 = 3;

		// navigate to shop page
		HomePage homePage = new HomePage(driver);
		homePage.clickShopMenu();
		ShopPage shopPage = new ShopPage(driver);

		// add items to cart
		shopPage.getProduct(new CompareByTitle(productTitle1)).clickBuyButton();
		shopPage.getProduct(new CompareByTitle(productTitle2)).clickBuyButton();
		shopPage.getProduct(new CompareByTitle(productTitle2)).clickBuyButton();
		shopPage.getProduct(new CompareByTitle(productTitle2)).clickBuyButton();

		// navigate to cart page
		shopPage.clickCartMenu();
		CartPage cartPage = new CartPage(driver);

		// Verify the product price and Quantity
		Assert.assertEquals(myPrice1, cartPage.getPrice(productTitle1), 0);
		Assert.assertEquals(myQuantity2, cartPage.getQuantity(productTitle2));
	}

	@Test
	public void testSubtotalInShoppingCart() throws Exception {
		String productTitle = "Fluffy Bunny";

		// navigate to shop page
		HomePage homePage = new HomePage(driver);
		homePage.clickShopMenu();
		ShopPage shopPage = new ShopPage(driver);

		// add 2 items to cart
		shopPage.getProduct(new CompareByTitle(productTitle)).clickBuyButton();
		shopPage.getProduct(new CompareByTitle(productTitle)).clickBuyButton();

		// navigate to cart page
		shopPage.clickCartMenu();
		CartPage cartPage = new CartPage(driver);

		// Verify the subtotal is Quantity x price for the product
		double subTotal = (cartPage.getPrice(productTitle) * cartPage.getQuantity(productTitle));
		Assert.assertEquals(subTotal, cartPage.getSubtotal(productTitle), 0);
	}

	@Test
	public void testRemoveProductInCart() throws Exception {
		String productTitle = "Teddy Bear";
		String emptyCartMessage = "Your cart is empty - there's nothing to see here.";

		// navigate to shop page
		HomePage homePage = new HomePage(driver);
		homePage.clickShopMenu();
		ShopPage shopPage = new ShopPage(driver);

		// add 3 items to cart
		Product product = shopPage.getProduct(new CompareByTitle(productTitle));
		product.clickBuyButton();
		product.clickBuyButton();
		product.clickBuyButton();

		// navigate to cart page
		shopPage.clickCartMenu();
		CartPage cartPage = new CartPage(driver);
		
		// Remove the Item from the Cart
		cartPage.clickDeleteButton(productTitle);
		cartPage.confirmDeletion();
		
		//Verify that the cart is empty
		Assert.assertEquals(emptyCartMessage, cartPage.getEmptyCartMessage());
	}
	
	@Test
	public void testTotalInCart() throws Exception {
		String productTitle = "Stuffed Frog";
		double total=43.96;
		
		// navigate to shop page
		HomePage homePage = new HomePage(driver);
		homePage.clickShopMenu();
		ShopPage shopPage = new ShopPage(driver);

		// add 4 items to cart
		Product product = shopPage.getProduct(new CompareByTitle(productTitle));
		product.clickBuyButton();
		product.clickBuyButton();
		product.clickBuyButton();
		product.clickBuyButton();

		// navigate to cart page
		shopPage.clickCartMenu();
		CartPage cartPage = new CartPage(driver);
		
		//Verify the total value in Cart
	    Assert.assertEquals(total, cartPage.getTotal(),0);
	}
	

}
