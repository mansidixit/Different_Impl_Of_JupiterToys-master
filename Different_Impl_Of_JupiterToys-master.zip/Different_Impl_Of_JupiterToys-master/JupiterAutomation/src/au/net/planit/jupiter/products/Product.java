package au.net.planit.jupiter.products;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class Product {
	
	private WebElement el;
	public Product(WebElement el){
		this.el = el;
	}
	
	public String getProductTitle() {
		return el.findElement(By.className("product-title")).getText();
	}
	
	public double getProductPrice() {
		return Double.parseDouble(el.findElement(By.className("product-price")).getText().replace("$", ""));
	}
	
	public void clickBuyButton() {
		 el.findElement(By.linkText("Buy")).click();
	}
}
