package au.net.planit.jupiter.products;


public class CompareByTitle implements IComparison {

	private String productTitle;

	public CompareByTitle(String productTitle) {
		this.productTitle = productTitle;
	}

	@Override
	public boolean compareProduct(Product p){
		return this.productTitle.equals(p.getProductTitle());
	}
	
	public String toString(){
		return this.productTitle;
	}
}