package au.net.planit.jupiter.products;


public class CompareByPrice implements IComparison {

	private double productPrice;
	public CompareByPrice(double productPrice){
		this.productPrice = productPrice;
	}
	@Override
	public boolean compareProduct(Product product) {
		return (product.getProductPrice() == this.productPrice);
	}
	
	public String toString(){
		return String.valueOf(this.productPrice);
	}

}
