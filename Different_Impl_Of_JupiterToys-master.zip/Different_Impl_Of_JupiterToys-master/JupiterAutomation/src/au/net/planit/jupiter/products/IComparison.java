package au.net.planit.jupiter.products;


public interface IComparison {
	

	public boolean compareProduct(Product product);
}
