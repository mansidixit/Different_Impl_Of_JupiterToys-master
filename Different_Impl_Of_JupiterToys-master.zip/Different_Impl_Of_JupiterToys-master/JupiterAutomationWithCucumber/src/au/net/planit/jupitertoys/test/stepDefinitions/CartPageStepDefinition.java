package au.net.planit.jupitertoys.test.stepDefinitions;

import org.junit.Assert;

import au.net.planit.jupitertoys.page.CartPage;
import au.net.planit.jupitertoys.page.HomePage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CartPageStepDefinition extends BaseStepDefinition {

	@Given("^I am on the Cart page with preselected products$")
	public void i_am_on_the_Cart_page_with_preselected_products()
			throws Exception {
		HomePage homePage = new HomePage(driver);
		homePage.clickCartMenu();
	}

	@When("^I change the quantity of (.+) to (\\d+)$")
	public void i_change_the_quantity_of_product_to(String productTitle,
			String quantity) throws Exception {
		CartPage cartPage = new CartPage(driver);
		cartPage.setQuantity(productTitle,quantity);
	}

	@Then("^The Subtotal  of (.+) changes to (\\d+.\\d+)$")
	public void the_Subtotal_of_product_changes_to_$(String productTitle,
			double subTotal) throws Exception {
		CartPage cartPage = new CartPage(driver);
		Assert.assertEquals(subTotal, cartPage.getSubtotal(productTitle), 0);
	}
}
