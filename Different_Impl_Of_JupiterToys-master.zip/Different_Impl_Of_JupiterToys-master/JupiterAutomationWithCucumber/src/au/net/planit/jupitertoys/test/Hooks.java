package au.net.planit.jupitertoys.test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;

public class Hooks {

	private static WebDriver driver;

	@After
	public static void tearDownAfterTest() {
		driver.quit();
	}

	@Before
	public static void setUpBeforeTests() {
		driver = new FirefoxDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.get("http://localhost/jupiter");
		driver.manage().deleteAllCookies();
	}

	public static WebDriver getDriver(){
		if(null!=driver){
			return driver;
		}
		return null;
	}
}
