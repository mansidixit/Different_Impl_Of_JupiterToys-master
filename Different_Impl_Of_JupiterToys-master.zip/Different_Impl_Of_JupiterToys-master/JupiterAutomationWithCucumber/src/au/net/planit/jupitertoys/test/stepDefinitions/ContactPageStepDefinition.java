package au.net.planit.jupitertoys.test.stepDefinitions;


import java.util.List;

import org.junit.Assert;

import au.net.planit.jupitertoys.page.ContactPage;
import au.net.planit.jupitertoys.page.HomePage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ContactPageStepDefinition extends BaseStepDefinition{
			
	@Given("^The Customer is on Contact Page$")
	public void the_Customer_is_on_Contact_Page() throws Throwable {
		//click Contact menu from Home page
		HomePage homePage = new HomePage(driver);
		homePage.clickContactMenu();
	}

	@When("^The Customer click submit$")
	public void the_Customer_clicks_submit() throws Throwable {
		// Click submit from Contact page
		ContactPage contactPage = new ContactPage(driver);
		contactPage.clickSubmit();
	}

	@Then("^Proper Validation Error messages are displayed for the requires fields$")
	public void proper_Validation_Error_messages_are_displayed_for_the_requires_fields() throws Throwable {
		ContactPage contactPage = new ContactPage(driver);
		Assert.assertEquals("Checks the foreName validation error message","Forename is required",contactPage.getForeNameValidationError());
		Assert.assertEquals("Checks the Email validation error message","Email is required",contactPage.getEmailValidationError());
		Assert.assertEquals("Checks the Message validation error message","Message is required",contactPage.getMessageValidationError());
	}

	@When("^The Customer fills in details in the form$")
	public void the_Customer_fills_in_details_in_the_form(List<String> formValues) {
		String foreName=formValues.get(0);
		ContactPage contactPage = new ContactPage(driver);
		contactPage.setForeName(foreName);
		contactPage.setSurname(formValues.get(1));
		contactPage.setEmail(formValues.get(2));
		contactPage.setTelephone(formValues.get(3));
		contactPage.setMessage(formValues.get(4));
	}

	@Then("^Success message is displayed with customer Forename \"(.*?)\"$")
	public void success_message_is_displayed_with_customer_s(String foreName)  {
		ContactPage contactPage = new ContactPage(driver);
		Assert.assertTrue("Check the correct forName is printed on the success page",contactPage.getSuccessMssage().contains(foreName));
	}
}
