package au.net.planit.jupitertoys.test.stepDefinitions;

import org.openqa.selenium.WebDriver;

import au.net.planit.jupitertoys.test.Hooks;

public class BaseStepDefinition {

	protected static WebDriver driver;

	public BaseStepDefinition() {
		BaseStepDefinition.driver = Hooks.getDriver();
	}

}
