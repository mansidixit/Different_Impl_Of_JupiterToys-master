package au.net.planit.jupitertoys.test.stepDefinitions;

import java.util.List;

import org.junit.Assert;

import au.net.planit.jupiter.products.CompareByTitle;
import au.net.planit.jupitertoys.page.HomePage;
import au.net.planit.jupitertoys.page.ShopPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ShopPageStepDefinition extends BaseStepDefinition{

		@Given("^I am on the page listing all products on Sale$")
		public void i_am_on_the_page_listing_all_products_on_Sale() {
			//click shop menu from Home page
			HomePage homePage = new HomePage(driver);
			homePage.clickShopMenu();
		}

		@When("^I click Buy the following Products$")
		public void i_click_Buy_the_following_Products(List<String> products) throws Exception {
	
			ShopPage shopPage = new ShopPage(driver);
			for(String productName : products){
				shopPage.getProduct(new CompareByTitle(productName)).clickBuyButton();
			}
		}

		@Then("^The Cart menu should be updated as (.*)$")
		public void the_Cart_menu_should_be_updated_as(String totalProductsBought) throws Exception {
			ShopPage shopPage = new ShopPage(driver);
			Assert.assertEquals("Tha number of items bought do not match the number shown Cart",totalProductsBought,shopPage.getProductCountInCartMenu());
		}
}
