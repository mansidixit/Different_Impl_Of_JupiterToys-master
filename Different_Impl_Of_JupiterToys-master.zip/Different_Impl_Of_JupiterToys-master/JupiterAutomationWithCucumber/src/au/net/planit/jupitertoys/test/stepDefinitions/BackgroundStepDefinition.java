package au.net.planit.jupitertoys.test.stepDefinitions;

import java.util.List;

import au.net.planit.jupiter.products.CompareByTitle;
import au.net.planit.jupitertoys.page.HomePage;
import au.net.planit.jupitertoys.page.ShopPage;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class BackgroundStepDefinition extends BaseStepDefinition{

		@When("^I am about to run any scenario in the cartPage$")
		public void i_am_about_to_run_any_scenario_in_the_cartPage() throws Exception {
			HomePage homePage = new HomePage(driver);
			homePage.clickShopMenu();
		}

		@Then("^I want atleast one products to be present in the cart$")
		public void i_want_atleast_one_products_to_be_present_in_the_cart(List<String> product) throws Exception {
			ShopPage shopPage = new ShopPage(driver);
			for(String products : product){
				shopPage.getProduct(new CompareByTitle(products)).clickBuyButton();
			}

		}

}
